To update QuickSmith to version 5.01 which fixes a printing issue just
unzip the executable and copy it into your prior installation directory.
If you first rename your current version to QSmith_32_500.exe you will
be able to 'rollback' your upgrade should you discover a problem.